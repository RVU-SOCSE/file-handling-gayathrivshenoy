try:
    file=open("Sample.txt", "r")
    content=file.read()
    print(content)
except FileNotFoundError:
    print("File does not exist")
