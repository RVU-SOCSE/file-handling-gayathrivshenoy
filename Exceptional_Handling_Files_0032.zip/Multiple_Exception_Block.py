try:
    a=int(input("Enter number: "))
    b=int(input"Enter number: "))
    print(a/b)
except ValueError:
    print("Error Occured Enter number")
except ZeroDivisionError:
    print("Zero Division error")
