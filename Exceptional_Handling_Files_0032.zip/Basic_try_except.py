try:
    a=10
    b=0
    print(a/b)
except:
    print("Error occured")
