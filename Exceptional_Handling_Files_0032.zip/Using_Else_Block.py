try:
    a=10
    b=2
    result=a/b
except ZeroDivisionError:
    print("Division not allowed by zero")
else:
    print("Result: ", result)
