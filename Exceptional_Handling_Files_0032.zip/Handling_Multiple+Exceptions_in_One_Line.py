try:
    num=int("abc")
except(ValueError, TypeError):
    print("Error occured while converting value")
