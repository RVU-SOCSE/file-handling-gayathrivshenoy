class MyError(Exception):
    pass
try:
    raise MyError("Custom Error Occrred")
except MyError as e:
    print(e)
