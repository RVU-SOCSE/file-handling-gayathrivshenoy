try:
    num=int(input(?"Enter a number: "))
    print(num)
except ValueError:
    print("Invalid Output! Please enter a number.")
    
