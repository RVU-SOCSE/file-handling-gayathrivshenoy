age=-5
if age<0:
    raise ValueError("Age cannot be negetive")
